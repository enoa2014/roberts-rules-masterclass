/**
 * Shared Logic for Multi-Page Courseware
 */

const courseStructure = [
    {
        title: "Home",
        items: [
            { text: "课程概览", id: "home", page: "index.html", folder: "root" }
        ]
    },
    {
        title: "Module 1: 权力的游戏",
        items: [
            { text: "1.1 混沌与秩序", id: "m1-1", page: "module-1.html", hash: "#section1", folder: "pages" },
            { text: "1.2 历史的智慧", id: "m1-2", page: "module-1.html", hash: "#section2", folder: "pages" },
            { text: "1.3 罗伯特与孙中山", id: "m1-3", page: "module-1.html", hash: "#section3", folder: "pages" }
        ]
    },
    {
        title: "Module 2: 核心十二条",
        items: [
            { text: "2.1 秩序组 (Order)", id: "m2-1", page: "module-2.html", folder: "pages" },
            { text: "2.2 效率组 (Efficiency)", id: "m2-2", page: "module-2.html", hash: "#group2", folder: "pages" },
            { text: "2.3 决策组 (Decision)", id: "m2-3", page: "module-2.html", hash: "#group3", folder: "pages" }
        ]
    },
    {
        title: "Module 3: 高阶动议体系",
        items: [
            { text: "3.1 动议解剖学", id: "m3-1", page: "module-3.html", folder: "pages" },
            { text: "3.2 优先权体系", id: "m3-2", page: "module-3.html", hash: "#rank", folder: "pages" }
        ]
    },
    {
        title: "Module 4: 实战演练",
        items: [
            { text: "4.1 家庭会议", id: "m4-1", page: "module-4.html", folder: "pages" },
            { text: "4.2 业主委员会", id: "m4-2", page: "module-4.html", hash: "", folder: "pages" }
        ]
    },
    {
        title: "Module 5: 工具箱",
        items: [
            { text: "5.1 议程模版", id: "m5-1", page: "module-5.html", folder: "pages" }
        ]
    }
];

document.addEventListener('DOMContentLoaded', () => {
    // Determine current location context
    const path = window.location.pathname;
    const isPagesDir = path.includes('/pages/');

    renderSidebar(isPagesDir);
    highlightActive();
});

function renderSidebar(isPagesDir) {
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return;

    sidebar.innerHTML = `
        <div class="brand">
            <span>🏛</span> 议事规则大师课
        </div>
    `;

    courseStructure.forEach(group => {
        const groupDiv = document.createElement('div');
        groupDiv.className = 'nav-group';

        const title = document.createElement('div');
        title.className = 'nav-title';
        title.innerText = group.title;
        groupDiv.appendChild(title);

        group.items.forEach(item => {
            const link = document.createElement('a');
            link.className = 'nav-link';
            link.innerText = item.text;

            // Calculate HREF based on context
            let href = "";

            if (isPagesDir) {
                // We are in /pages/
                if (item.folder === "root") {
                    href = "../" + item.page;
                } else {
                    href = item.page; // Sibling
                }
            } else {
                // We are in root /
                if (item.folder === "root") {
                    href = item.page;
                } else {
                    href = "pages/" + item.page;
                }
            }

            if (item.hash) href += item.hash;
            link.href = href;

            groupDiv.appendChild(link);
        });

        sidebar.appendChild(groupDiv);
    });
}

function highlightActive() {
    // Simple naive highlighting
    const currentFile = window.location.pathname.split('/').pop() || 'index.html';
    const links = document.querySelectorAll('.nav-link');
    links.forEach(l => {
        if (l.getAttribute('href').includes(currentFile)) {
            l.classList.add('active');
        }
    });
}
