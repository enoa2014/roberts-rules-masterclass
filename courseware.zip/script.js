/**
 * Course Engine Script
 * Handles routing, rendering, state, and interactivity.
 */

/* State */
let currentState = {
    mIndex: 0,
    sIndex: 0,
    completed: new Set(), // Set of "mIndex-sIndex" strings
    theme: 'light'
};

/* Init */
document.addEventListener('DOMContentLoaded', () => {
    loadState();
    renderSidebar();
    renderContent();
    updateUI();

    // Theme
    if (localStorage.getItem('theme') === 'dark') {
        document.body.setAttribute('data-theme', 'dark');
        currentState.theme = 'dark';
    }

    /* Event Listeners */
    document.getElementById('btnPrev').addEventListener('click', prevSection);
    document.getElementById('btnNext').addEventListener('click', nextSection);
    document.getElementById('themeToggle').addEventListener('click', toggleTheme);
});

/* ----------------------------------------------------------------
   Core Rendering
---------------------------------------------------------------- */

function renderSidebar() {
    const nav = document.getElementById('courseNav');
    nav.innerHTML = '';

    courseData.modules.forEach((mod, mIdx) => {
        // Module Title
        const modTitle = document.createElement('div');
        modTitle.className = 'nav-module-title';
        modTitle.innerText = mod.title;
        nav.appendChild(modTitle);

        // Sections
        mod.sections.forEach((sec, sIdx) => {
            const item = document.createElement('div');
            item.className = 'nav-item';
            item.id = `nav-${mIdx}-${sIdx}`;
            item.innerHTML = `
                <span>${sec.title}</span>
                <span class="status-icon"></span>
            `;
            item.onclick = () => jumpTo(mIdx, sIdx);
            nav.appendChild(item);
        });
    });
}

function renderContent() {
    const section = getCurrentSection();
    const container = document.getElementById('contentArea');

    // Fade Out effect could go here
    container.innerHTML = `<div class="content-container"></div>`;
    const wrapper = container.querySelector('.content-container');

    // Breadcrumbs
    document.getElementById('moduleTitle').innerText = courseData.modules[currentState.mIndex].title;
    document.getElementById('sectionTitle').innerText = section.title;

    // Build Content based on Type
    switch (section.type) {
        case 'reading':
            wrapper.innerHTML = `<h2>${section.title}</h2>${section.content}`;
            break;
        case 'interactive-concept':
            wrapper.innerHTML = `<h2>${section.title}</h2><div class="card-stack"></div>`;
            const stack = wrapper.querySelector('.card-stack');
            section.concepts.forEach(c => {
                stack.innerHTML += `
                    <div class="info-card">
                        <h4>${c.term}</h4>
                        <p>${c.desc}</p>
                    </div>`;
            });
            break;
        case 'quiz':
            renderQuiz(wrapper, section);
            break;
        case 'card-stack':
            wrapper.innerHTML = `<h2>${section.title}</h2>`; // content text if any
            if (section.content) wrapper.innerHTML += section.content;
            wrapper.innerHTML += `<div class="card-stack"></div>`;
            const cStack = wrapper.querySelector('.card-stack');
            section.cards.forEach(card => {
                cStack.innerHTML += `
                    <div class="info-card">
                        <h4>${card.title}</h4>
                        <p>${card.desc}</p>
                        <div class="case-study">💡 ${card.case}</div>
                    </div>`;
            });
            break;
        case 'simulation':
            renderSimulation(wrapper, section);
            break;
        case 'certificate':
            wrapper.innerHTML = `
                <div style="text-align:center; padding: 40px;">
                    <h2>🎉 课程完成</h2>
                    <p>你已经完成了所有模块的学习。</p>
                    <div style="border:10px solid #d97706; padding: 40px; margin: 20px 0; background:#fffbeb; color:#92400e;">
                        <h1>结业证书</h1>
                        <p>授予：学习者</p>
                        <p>已掌握：议事规则基础机制</p>
                    </div>
                    <button class="btn-nav" onclick="window.print()">打印证书</button>
                </div>
            `;
            break;
    }

    // Mark as visited/completed immediately for reading types
    // For quizzes, maybe wait? For now, simple completion.
    markCompleted(currentState.mIndex, currentState.sIndex);
    updateUI();
}

/* ----------------------------------------------------------------
   Component Logics
---------------------------------------------------------------- */

function renderQuiz(container, section) {
    container.innerHTML = `<h2>${section.title}</h2>`;
    section.questions.forEach((q, qIdx) => {
        const qBox = document.createElement('div');
        qBox.className = 'quiz-container';
        qBox.innerHTML = `<h3>问题 ${qIdx + 1}: ${q.q}</h3><div class="options"></div><div class="feedback"></div>`;
        const optsDiv = qBox.querySelector('.options');

        q.options.forEach((opt, oIdx) => {
            const btn = document.createElement('button');
            btn.className = 'option-btn';
            btn.innerText = opt;
            btn.onclick = () => {
                // Check answer
                const allBtns = optsDiv.querySelectorAll('.option-btn');
                allBtns.forEach(b => b.disabled = true);

                const fb = qBox.querySelector('.feedback');
                fb.style.display = 'block';

                if (oIdx === q.answer) {
                    btn.classList.add('correct');
                    fb.innerHTML = `✅ <strong>回答正确！</strong> ${q.explanation}`;
                    fb.style.backgroundColor = '#dcfce7';
                    fb.style.color = '#14532d';
                } else {
                    btn.classList.add('wrong');
                    allBtns[q.answer].classList.add('correct'); // Show correct
                    fb.innerHTML = `❌ <strong>回答错误。</strong> ${q.explanation}`;
                    fb.style.backgroundColor = '#fee2e2';
                    fb.style.color = '#7f1d1d';
                }
            };
            optsDiv.appendChild(btn);
        });
        container.appendChild(qBox);
    });
}

function renderSimulation(container, section) {
    container.innerHTML = `
        <h2>${section.title}</h2>
        <div class="chat-box">
            <div class="chat-history" id="simChat"></div>
            <div class="choices" id="simChoices"></div>
        </div>
    `;

    // Start Logic
    runSimNode(section.nodes, section.startNode);
}

function runSimNode(nodes, nodeId) {
    const node = nodes[nodeId];
    const history = document.getElementById('simChat');
    const controls = document.getElementById('simChoices');

    // Add History
    const bubble = document.createElement('div');
    bubble.className = 'msg-bubble';
    bubble.innerText = node.text;
    history.appendChild(bubble);
    history.scrollTop = history.scrollHeight;

    // Render Options
    controls.innerHTML = '';

    if (node.isEnd) {
        const resetBtn = document.createElement('button');
        resetBtn.className = 'choice-btn';
        resetBtn.innerText = '🔄 重新开始模拟';
        resetBtn.style.backgroundColor = '#78716c';
        resetBtn.onclick = () => {
            document.getElementById('simChat').innerHTML = '';
            runSimNode(nodes, "node1"); // hardcoded start or pass it
        };
        controls.appendChild(resetBtn);
    } else {
        node.options.forEach(opt => {
            const btn = document.createElement('button');
            btn.className = 'choice-btn';
            btn.innerText = opt.text;
            btn.onclick = () => runSimNode(nodes, opt.next);
            controls.appendChild(btn);
        });
    }
}

/* ----------------------------------------------------------------
   Navigation & Utilities
---------------------------------------------------------------- */

function getCurrentSection() {
    return courseData.modules[currentState.mIndex].sections[currentState.sIndex];
}

function jumpTo(m, s) {
    currentState.mIndex = m;
    currentState.sIndex = s;
    saveState();
    renderContent();
    updateUI();
}

function nextSection() {
    const mod = courseData.modules[currentState.mIndex];
    if (currentState.sIndex < mod.sections.length - 1) {
        currentState.sIndex++;
    } else if (currentState.mIndex < courseData.modules.length - 1) {
        currentState.mIndex++;
        currentState.sIndex = 0;
    }
    jumpTo(currentState.mIndex, currentState.sIndex);
}

function prevSection() {
    if (currentState.sIndex > 0) {
        currentState.sIndex--;
    } else if (currentState.mIndex > 0) {
        currentState.mIndex--;
        currentState.sIndex = courseData.modules[currentState.mIndex].sections.length - 1;
    }
    jumpTo(currentState.mIndex, currentState.sIndex);
}

function updateUI() {
    // Nav Active State
    document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active', 'completed'));

    // Highlight Current
    const activeId = `nav-${currentState.mIndex}-${currentState.sIndex}`;
    const activeEl = document.getElementById(activeId);
    if (activeEl) activeEl.classList.add('active');

    // Mark Completed
    currentState.completed.forEach(key => {
        const el = document.getElementById(`nav-${key}`);
        if (el) el.classList.add('completed');
    });

    // Sidebar Progress Bar
    const totalSections = courseData.modules.reduce((acc, m) => acc + m.sections.length, 0);
    const completedCount = currentState.completed.size;
    const pct = Math.round((completedCount / totalSections) * 100);
    document.getElementById('globalProgress').innerText = `${pct}%`;
    document.getElementById('globalProgressBar').style.width = `${pct}%`;

    // Button States
    document.getElementById('btnPrev').disabled = (currentState.mIndex === 0 && currentState.sIndex === 0);
    const isLast = (currentState.mIndex === courseData.modules.length - 1 && currentState.sIndex === courseData.modules[courseData.modules.length - 1].sections.length - 1);
    document.getElementById('btnNext').innerText = isLast ? '完成' : '下一节';
    document.getElementById('btnNext').disabled = isLast; // Optional: disable or show finish modal
}

function markCompleted(m, s) {
    const key = `${m}-${s}`;
    if (!currentState.completed.has(key)) {
        currentState.completed.add(key);
        saveState();
    }
}

/* ----------------------------------------------------------------
   Persistence
---------------------------------------------------------------- */

function saveState() {
    const data = {
        m: currentState.mIndex,
        s: currentState.sIndex,
        completed: Array.from(currentState.completed)
    };
    localStorage.setItem('course_progress', JSON.stringify(data));
}

function loadState() {
    const saved = localStorage.getItem('course_progress');
    if (saved) {
        const data = JSON.parse(saved);
        currentState.mIndex = data.m;
        currentState.sIndex = data.s;
        currentState.completed = new Set(data.completed);
    }
}

function resetProgress() {
    if (confirm("确定要重置学习进度吗？")) {
        localStorage.removeItem('course_progress');
        location.reload();
    }
}

function toggleTheme() {
    const body = document.body;
    if (body.getAttribute('data-theme') === 'dark') {
        body.removeAttribute('data-theme');
        localStorage.setItem('theme', 'light');
    } else {
        body.setAttribute('data-theme', 'dark');
        localStorage.setItem('theme', 'dark');
    }
}
