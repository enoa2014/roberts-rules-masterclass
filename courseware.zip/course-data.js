/**
 * 2-Hour Self-Study Course Content Data
 * Expanded from original PDF with supplementary educational material.
 */

const courseData = {
    meta: {
        title: "议事规则：理性与共识的艺术",
        description: "2小时沉浸式自学课程",
        author: "议起读"
    },
    modules: [
        {
            id: "m1",
            title: "第一章：规则的起源与精神",
            duration: "30分钟",
            sections: [
                {
                    id: "s1-1",
                    title: "引言：为什么需要规则？",
                    type: "reading",
                    content: `
                        <h3>当争论发生时...</h3>
                        <p>你一定经历过这样的场景：公司会议上，大家为了一个方案争得面红耳赤，最后谁也说服不了谁；或者家庭会议里，因为一两句情绪化的话语，原本的讨论变成了互相指责。</p>
                        <p><strong>这就是"无序讨论"的代价。</strong></p>
                        <p>议事规则（Parliamentary Procedure）并不是为了限制发言，恰恰相反，它的诞生是为了<strong>保护每个人发言的权利</strong>，并确保讨论能得出一个确定的结果。</p>
                        <div class="highlight-box">
                            <strong>思考：</strong> 在你最近的一次无效沟通中，如果有一个"裁判"在场，情况会不会不同？
                        </div>
                    `
                },
                {
                    id: "s1-2",
                    title: "历史溯源：罗伯特与孙中山",
                    type: "reading",
                    content: `
                        <h3>1876年的那次会议</h3>
                        <p>不管是联合国大会，还是美国的国会，甚至是一个小区的业主委员会，大多遵循着一套相似的规则。这套规则的奠基人是美国陆军准将——<strong>亨利·马丁·罗伯特 (Henry M. Robert)</strong>。</p>
                        <p>1876年，他在一次教会会议上主持失败，深感混乱，于是立誓要编写一套适用于普通社团的议事规则。这就是著名的《罗伯特议事规则》(Robert's Rules of Order)。</p>
                        
                        <h3>孙中山的《民权初步》</h3>
                        <p>目光回到中国。1917年，孙中山先生敏锐地意识到，国人"一盘散沙"的根本原因在于缺乏集体协作的训练。</p>
                        <p>他在《建国方略》中专门写了一本<strong>《民权初步》</strong>，详细介绍了开会的方法。他说：<strong>"集会者，实为民权发达之第一步。"</strong></p>
                        <p>学会如何开会，就是学会如何行使民主权利。</p>
                    `
                },
                {
                    id: "s1-3",
                    title: "三大核心精神",
                    type: "interactive-concept",
                    concepts: [
                        {
                            term: "平等 (Equality)",
                            desc: "在规则面前，主席与成员平等，老手与新手平等。即使只有一个人持反对意见，他的声音也必须被听见。"
                        },
                        {
                            term: "尊重 (Respect)",
                            desc: "攻击观点，但不攻击人（对事不对人）。倾听是尊重的最高形式。不在此刻打断，是为了稍后完整地反驳。"
                        },
                        {
                            term: "理性 (Reason)",
                            desc: "用逻辑、事实和证据说话，而不是情绪、声量和权威。决策基于多数人的理性共识。"
                        }
                    ]
                },
                {
                    id: "s1-quiz",
                    title: "第一章小测",
                    type: "quiz",
                    questions: [
                        {
                            q: "孙中山先生认为，民权发达的第一步是什么？",
                            options: ["发展经济", "普及教育", "学会集会", "增强军力"],
                            answer: 2,
                            explanation: "孙中山在《民权初步》中指出：'集会者，实为民权发达之第一步。'"
                        },
                        {
                            q: "下列哪项行为违反了'尊重'原则？",
                            options: ["指出对方数据错误", "在对方发言时插话反驳", "记录对方的观点", "会后继续讨论"],
                            answer: 1,
                            explanation: "打断他人发言是对发言权的不尊重，哪怕你认为他是错的，也应等待其发言结束。"
                        }
                    ]
                }
            ]
        },
        {
            id: "m2",
            title: "第二章：老友议事规则十二条 (重点)",
            duration: "60分钟",
            sections: [
                {
                    id: "s2-intro",
                    title: "规则概览",
                    type: "reading",
                    content: `
                        <p>为了让复杂的《罗伯特议事规则》更易于普及，国内专家总结了"老友议事规则十二条"。这十二条是入门的黄金法则。</p>
                        <div class="rule-grid">
                            <span>1. 主持中立</span>
                            <span>2. 机会均等</span>
                            <span>3. 主持人权</span>
                            <span>4. 打断</span>
                            <span>5. 举手发言</span>
                            <span>6. 反对</span>
                            <span>7. 面向主持</span>
                            <span>8. 跑题</span>
                            <span>9. 先问后点</span>
                            <span>10. 攻击</span>
                            <span>11. 服从裁判</span>
                            <span>12. 多数决</span>
                        </div>
                    `
                },
                {
                    id: "s2-deep-1",
                    title: "核心规则详解：秩序篇",
                    type: "card-stack",
                    cards: [
                        {
                            title: "规则1：主持中立",
                            desc: "主持人是'裁判'，不是'教练'或'运动员'。主持人不能发表倾向性意见，如果想发言，必须暂时卸任主持人身份。",
                            case: "错误示范：主持人说'我觉得小王的提议不好，大家不要投他。'"
                        },
                        {
                            title: "规则4：面向主持",
                            desc: "所有发言必须看着主持人说，而不是盯着你的辩论对手。这能有效降低冲突热度，把'人与人的对抗'转化为'人与议题的互动'。",
                            case: "正确示范：发言者看着主持人说：'主持人，我认为刚才对方的观点有待商榷...'，而不是指着对方说'你错了！'"
                        }
                    ]
                },
                {
                    id: "s2-deep-2",
                    title: "核心规则详解：效率篇",
                    type: "card-stack",
                    cards: [
                        {
                            title: "规则7：不超时",
                            desc: "时间是公共资源。通常规定每人每次发言不超过2分钟。超时必须立即停止。",
                            case: "技巧：使用倒计时器，剩余30秒时举牌提示。"
                        },
                        {
                            title: "规则8：不跑题",
                            desc: "讨论必须围绕当前动议进行。如果讨论由于A方案跑到了B方案，主持人应立即打断拉回。",
                            case: "主持人话术：'请注意，我们现在讨论的是预算问题，而不是人事问题，请回到议题。'"
                        }
                    ]
                },
                {
                    id: "s2-deep-3",
                    title: "核心规则详解：权利篇",
                    type: "card-stack",
                    cards: [
                        {
                            title: "规则2：机会均等",
                            desc: "发言机会要轮流分配。优先让'未发言者'发言，优先让'持不同意见者'发言。",
                            case: "场景：A举手了5次，B第一次举手。主持人应点B发言。"
                        },
                        {
                            title: "规则10：不攻击",
                            desc: "严禁进行人身攻击、动机揣测。只能攻击观点逻辑。",
                            case: "严重违规：'你这就是自私！'（攻击动机）。正确质疑：'这个方案对集体利益有潜在风险。'"
                        }
                    ]
                }
            ]
        },
        {
            id: "m3",
            title: "第三章：实战模拟",
            duration: "20分钟",
            sections: [
                {
                    id: "s3-intro",
                    title: "场景说明",
                    type: "reading",
                    content: `
                        <h3>家庭会议：零花钱风波</h3>
                        <p><strong>背景：</strong> 10岁的儿子小明用奶奶偷偷给的200元充值了游戏。妈妈发现后非常生气，爸爸提议召开家庭会议解决。</p>
                        <p><strong>你的角色：</strong> 你将扮演<strong>爸爸（主持人）</strong>。</p>
                        <p>你的目标是：引导全家理性讨论，达成共识，而不是单纯的惩罚。</p>
                    `
                },
                {
                    id: "s3-sim",
                    title: "进入模拟",
                    type: "simulation",
                    startNode: "node1",
                    nodes: {
                        "node1": {
                            text: "妈妈：（拍桌子）这孩子简直无法无天了！200块钱啊！必须没收手机！\n\n作为主持人，你该怎么做？",
                            options: [
                                { text: "附和妈妈：'确实太不像话了！'", next: "fail1" },
                                { text: "敲击木槌（或杯子）：'请冷静。现在是开场陈述阶段，请妈妈先客观陈述事实，不要宣泄情绪。'", next: "node2" }
                            ]
                        },
                        "fail1": {
                            text: "你失去了中立立场，变成了妈妈的帮手。孩子感到被围攻，摔门而去。会议失败。",
                            isEnd: true,
                            status: "fail"
                        },
                        "node2": {
                            text: "妈妈深吸一口气，讲了事情经过。\n孩子：（委屈）那是奶奶给我的钱，属于我！我想怎么花就怎么花！\n妈妈：你的钱也是家里给的！\n两人开始吵架...\n\n你该怎么做？",
                            options: [
                                { text: "大声喝止：'都闭嘴！'", next: "fail2" },
                                { text: "提示规则：'请注意，会议中只能一个人发言，且必须面向主持人。孩子，现在是妈妈发言时间，请你记录下来，稍后专门让你反驳。'", next: "node3" }
                            ]
                        },
                        "fail2": {
                            text: "你虽然制止了争吵，但使用了权威压制，违背了'尊重'原则。气氛变得冰冷。",
                            isEnd: true,
                            status: "fail"
                        },
                        "node3": {
                            text: "这招很管用，孩子开始在纸上写写画画。大家情绪平复了。\n...经过一番讨论，大家同意建立'大额支出审批制'。\n\n最后表决时，奶奶说：'我弃权，我不懂你们这些。'\n此时赞成2票（爸妈），反对1票（孩子），弃权1票（奶）。\n\n决议通过了吗？",
                            options: [
                                { text: "通过了 (2 > 1)", next: "success" },
                                { text: "没通过 (需要过半数)", next: "node4" }
                            ]
                        },
                        "node4": {
                            text: "通常情况下，多数决只需'赞成票 > 反对票'（相对多数）即可。除非你们家规定了极严格的'绝对多数'（占总人数一半以上）。\n在这个场景下，2比1，通常视为通过。",
                            isEnd: true,
                            status: "success"
                        },
                        "success": {
                            text: "恭喜！根据'多数决'原则，决议有效。你成功引导了一场高质量的家庭会议！",
                            isEnd: true,
                            status: "success"
                        }
                    }
                }
            ]
        },
        {
            id: "m4",
            title: "第四章：结业",
            duration: "10分钟",
            sections: [
                {
                    id: "s4-final",
                    title: "课程总结",
                    type: "certificate",
                    content: "恭喜你完成了2小时的议事规则速成课程！"
                }
            ]
        }
    ]
};
