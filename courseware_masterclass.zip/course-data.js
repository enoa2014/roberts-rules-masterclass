/**
 * 8-Hour Masterclass Course Content
 * Covers Robert's Rules of Order basics, advanced motions, scenarios, and drafting.
 */

const courseData = {
    meta: {
        title: "议事规则：大师级实战研修班",
        description: "8小时系统性训练 · 从入门到精通",
        author: "议起读 PRO"
    },
    modules: [
        /* ============================================================
           PHASE 1: FOUNDATIONS (1.5 Hours)
           ============================================================ */
        {
            id: "m1",
            title: "第一章：议事规则的底层逻辑 (1.5h)",
            duration: "90分钟",
            sections: [
                {
                    id: "s1-1",
                    title: "导论：我们为什么不会开会？",
                    type: "reading",
                    content: `
                        <h3>中国式会议的痛点</h3>
                        <p>著名的管理学家彼得·德鲁克曾说："会议是组织的缺陷。"</p>
                        <p>而在中国当下的语境里，我们的低效会议通常表现为三种模式：</p>
                        <ul>
                            <li><strong>一言堂</strong>：领导讲了算，其他人玩手机。</li>
                            <li><strong>菜市场</strong>：大家一起说，谁大声听谁的。</li>
                            <li><strong>和稀泥</strong>：怕得罪人，议而决，决而不行。</li>
                        </ul>
                        <p>议事规则（Rules of Order）不仅是一套流程，更是一套<strong>分配权力的数学模型</strong>。它规定了谁在什么时候拥有控制空气震动的权利。</p>
                        <div class="highlight-box">
                            <strong>深度思考 (15分钟)：</strong> 
                            请回想你最近参加的3个会议，分别属于上述哪种模式？记录在你的笔记本上，并尝试分析原因。
                        </div>
                    `
                },
                {
                    id: "s1-2",
                    title: "历史：从罗马元老院到《罗伯特》",
                    type: "reading",
                    content: `
                        <p>（此处包含约 3000 字的详细历史阅读材料）...</p>
                        <h3>关键里程碑</h3>
                        <ul>
                            <li><strong>公元前509年</strong>：罗马元老院确立了发言顺序原则。</li>
                            <li><strong>1562年</strong>：英国议会初步成型，确立了"针对议题而非针对人"的辩论原则。</li>
                            <li><strong>1776年</strong>：杰斐逊起草《美国参议院议事规则手册》。</li>
                            <li><strong>1876年</strong>：亨利·罗伯特出版《罗伯特议事规则》，使规则平民化。</li>
                        </ul>
                    `
                },
                {
                    id: "s1-3",
                    title: "核心基石：权利的平衡",
                    type: "interactive-concept",
                    concepts: [
                        { term: "多数人的权利", desc: "最终决策权。多数人可以说'我们决定这样做'。" },
                        { term: "少数人的权利", desc: "发言权与知情权。少数人有权说'即使我要输，我也要让你听到我的理由'。" },
                        { term: "缺席者的权利", desc: "通过'法定人数 (Quorum)'机制保护。如果你没来，我们不能趁机把家分了。" },
                        { term: "整体的权利", desc: "规则本身的稳定性。必须有2/3多数才能修改规则。" }
                    ]
                }
            ]
        },

        /* ============================================================
           PHASE 2: THE 12 RULES DEEP DIVE (2 Hours)
           ============================================================ */
        {
            id: "m2",
            title: "第二章：十二条黄金法则深度剖析 (2h)",
            duration: "120分钟",
            sections: [
                {
                    id: "s2-intro",
                    title: "学习指南",
                    type: "reading",
                    content: `
                        <p>本章节我们将逐一拆解"老友议事规则十二条"。对于每一条规则，我们不仅要知其然，还要知其所以然。</p>
                        <p><strong>必须完成：</strong> 每一组规则后的案例判定测验。</p>
                    `
                },
                {
                    id: "s2-group1",
                    title: "秩序组：构建安全感",
                    type: "card-stack",
                    cards: [
                        { title: "主持中立", desc: "主持人为何不能发言？因为'裁判员下场踢球'会导致公信力崩塌。一旦主持人发表观点，反对者就会认为之后的裁决是不公的。", case: "高阶技巧：如果是小型会议主席必须发言，应临时移交主持权给副主席，直到该议题结束。" },
                        { title: "面向主持", desc: "为什么不能直接对话？直视对手会唤醒灵长类动物的'战斗本能'。看着主持人说话，相当于加了一层物理和心理的缓冲区。", case: "话术：'主席先生，我完全不同意刚才那位成员的荒谬言论'（虽然词很重，但看着主席说，冲突感骤降）。" }
                    ]
                },
                {
                    id: "s2-quiz1",
                    title: "实战判例：秩序篇",
                    type: "quiz",
                    questions: [
                        {
                            q: "会议中，成员A指责成员B说谎。主持人应该怎么做？",
                            options: ["静观其变", "立即打断A，判定其'人身攻击'犯规", "让B解释", "询问大家看法"],
                            answer: 1,
                            explanation: "主持人主要职责是维护秩序。人身攻击属于严重犯规，必须第一时间制止，保护B的权益。"
                        }
                    ]
                },
                {
                    id: "s2-group2",
                    title: "效率组：时间就是生命",
                    type: "reading",
                    content: `
                        <h3>不超时与不跑题</h3>
                        <p>在罗伯特规则中，默认每人对每个议题有2次发言机会，每次10分钟。但在现代快节奏会议中，我们通常建议修正为：</p>
                        <ul>
                            <li><strong>限制：</strong> 每人每次 2-3 分钟。</li>
                            <li><strong>工具：</strong> 必须有可视化的倒计时器。</li>
                        </ul>
                        <p><strong>跑题判定：</strong> 任何必须需要"只有解决了XX才能解决当前问题"的论述，通常都不算跑题。单纯的抱怨、回忆往事通常是跑题。</p>
                    `
                }
            ]
        },

        /* ============================================================
           PHASE 3: MOTIONS SYSTEM (2.5 Hours)
           ============================================================ */
        {
            id: "m3",
            title: "第三章：高阶动议体系 (2.5h)",
            duration: "150分钟",
            sections: [
                {
                    id: "s3-intro",
                    title: "动议 (Motion) 的解剖学",
                    type: "reading",
                    content: `
                        <h3>什么是动议？</h3>
                        <p>动议就是"我想让组织做某事"的正式提议。一个完整的动议生命周期如下：</p>
                        <ol>
                            <li><strong>动议 (Motion)</strong>：成员提出 "我动议把办公室墙漆成粉色。"</li>
                            <li><strong>附议 (Second)</strong>：另一人说 "我附议。" (表示至少有2人感兴趣，值得讨论)</li>
                            <li><strong>陈述 (Chair states question)</strong>：主持人重复议题，正式进入议程。</li>
                            <li><strong>辩论 (Debate)</strong>：正反方交替发言。</li>
                            <li><strong>表决 (Vote)</strong>：举手或投票。</li>
                            <li><strong>宣布 (Result)</strong>：主持人宣布结果。</li>
                        </ol>
                    `
                },
                {
                    id: "s3-rank",
                    title: "优先体系：谁能打断谁？",
                    type: "interactive-concept",
                    concepts: [
                        { term: "0. 主动议 (Main Motion)", desc: "最低级。只有没别的事时才能提。例如'买如果不买咖啡机'。" },
                        { term: "1. 附属动议 (Subsidiary)", desc: "针对主动议的修修补补。比如'修改'、'延期'。它们可以打断主动议的讨论。" },
                        { term: "2. 优先动议 (Privileged)", desc: "紧急且无关议题的事。比如'太吵了听不见'、'要求休会'。级别最高，随时插队。" }
                    ]
                },
                {
                    id: "s3-sim-rank",
                    title: "游戏：优先级挑战",
                    type: "simulation",
                    startNode: "start",
                    nodes: {
                        "start": {
                            text: "当前会议正在讨论【主动议】：'周末去爬山'。\n\n大家讨论得正热烈，成员A突然举手说：'我动议把地点改成去海边'（这是【修改动议】）。\n此时，成员B突然捂着肚子说：'我动议立即休会，空调坏了太热了'（这是【休会动议】）。\n\n作为主持人，你该先处理哪个？",
                            options: [
                                { text: "继续讨论爬山 (忽略插嘴)", next: "fail1" },
                                { text: "先处理A的修改：去海边", next: "fail2" },
                                { text: "先处理B的休会请求", next: "success" }
                            ]
                        },
                        "fail1": {
                            text: "错误。附属动议和优先动议都有权打断主动议。置之不理是违规的。",
                            isEnd: true
                        },
                        "fail2": {
                            text: "错误。虽然A打断了爬山讨论，但是B的'休会'属于优先动议，级别比'修改'更高。根据优先体系：优先动议 > 附属动议 > 主动议。",
                            isEnd: true
                        },
                        "success": {
                            text: "正确！优先动议 (Privileged) 级别最高，必须立即处理。你应该先表决是否休会。如果休会未通过，再回过头来处理A的修改动议，最后才是原本的爬山动议。",
                            isEnd: true
                        }
                    }
                }
            ]
        },

        /* ============================================================
           PHASE 4: APPLICATION & DRAFTING (1.5 Hours)
           ============================================================ */
        {
            id: "m4",
            title: "第四章：场景实战与文书写作 (1.5h)",
            duration: "90分钟",
            sections: [
                {
                    id: "s4-docs",
                    title: "作业：起草议程 (Agenda)",
                    type: "reading",
                    content: `
                        <h3>没有议程的会议是灾难</h3>
                        <p>标准议程结构通常包含：</p>
                        <ol>
                            <li>宣布开会 (Call to Order)</li>
                            <li>审批上次会议纪要</li>
                            <li>报告 (Reports)</li>
                            <li>未决事项 (Old Business) - 上次没谈完的</li>
                            <li><strong>新事项 (New Business)</strong> - 今天的重点</li>
                            <li>宣布散会</li>
                        </ol>
                        <div class="highlight-box">
                            <strong>线下作业：</strong> 请打开你的文档编辑器，为你下周的部门例会起草一份符合罗伯特规则的标准议程。
                        </div>
                    `
                },
                {
                    id: "s4-sim-hoa",
                    title: "地狱级实战：业主委员会",
                    type: "simulation",
                    startNode: "h1",
                    nodes: {
                        "h1": {
                            text: "场景：小区业委会讨论'是否更换物业'。\n现场有50人，不仅有业主，还有物业派来的'旁听人员'起哄。扩音器声音很大。\n\n有人大喊：'物业滚出去！' 现场一片混乱。\n\n作为主持人，第一步做什么？",
                            options: [
                                { text: "大声喊：'大家安静！听我说！'", next: "h_fail1" },
                                { text: "敲槌，宣布休会10分钟，安保清场非受邀人员", next: "h_ok1" }
                            ]
                        },
                        "h_fail1": {
                            text: "你的声音被淹没在嘈杂中。由于没有清除干扰源，会议无法进行。失败。",
                            isEnd: true
                        },
                        "h_ok1": {
                            text: "高明。'旁听人员'若扰乱秩序，由于他们不是会员，没有权利在此，应当驱逐。休会能让过热的情绪降温。\n\n（更多剧情省略...）",
                            isEnd: true
                        }
                    }
                }
            ]
        },

        /* ============================================================
           PHASE 5: FINAL EXAM (0.5 Hours)
           ============================================================ */
        {
            id: "m5",
            title: "第五章：大师结业考",
            duration: "30分钟",
            sections: [
                {
                    id: "final-quiz",
                    title: "综合测试",
                    type: "quiz",
                    questions: [
                        {
                            q: "动议按照优先级从高到低排列，正确的是？",
                            options: ["修改 > 休会 > 主动议", "休会 > 修改 > 主动议", "主动议 > 修改 > 休会"],
                            answer: 1,
                            explanation: "优先动议(休会) > 附属动议(修改) > 主动议。"
                        },
                        {
                            q: "在表决时，主持人投了一票导致出现平局。此时动议处于什么状态？",
                            options: ["通过", "否决", "需重新表决", "由主持人决定"],
                            answer: 1,
                            explanation: "根据规则，平局意味着未能获得'多数'支持，因此自动归为否决。主持人投反对票制造平局是一种常见的阻击策略。"
                        },
                        {
                            q: "一名成员对主持人的裁决表示不服，他应该？",
                            options: ["大声抗议", "提出'申诉动议 (Appeal)'", "离场抗议", "等待下次会议"],
                            answer: 1,
                            explanation: "对裁判不服，可以提出Appeal，由全体大会表决是否推翻主持人的裁决。这是民主制衡的核心。"
                        }
                    ]
                },
                {
                    id: "cert",
                    title: "领取证书",
                    type: "certificate"
                }
            ]
        }
    ]
};
